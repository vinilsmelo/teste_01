* Ipeúna / SP
* Piracaia / SP
* Rio das Pedras / SP
