* Água Boa - MT
* Alfenas - MG
* Almirante Tamandaré - PR
* Barracão - PR
* Braço do Norte - SC
* Bento Gonçalves - RS
* Bombinhas - SC
* Capão da Canoa - RS
* Capinzal - SC
* Catanduvas - SC
* Chapecó - SC
* Cocal do Sul - SC
* Congonhas - MG
* Cornélio Procópio - PR
* Criciúma - SC
* Dionísio Cerqueira - SC
* Imbituba - SC
* Garopaba - SC
* General Carneiro - PR
* Goioerê - PR
* Fazenda Rio Grande - PR
* Juti - MS
* Joaçaba - SC
* Itapiranga - SC
* Itaú de Minas - MG
* Lages - SC
* Laguna - SC
* Mandaguaçu - PR
* Mandirituba - PR
* Maravilha - SC
* Mariana - MG
* Mococa - SP
* Morro da Fumaça - SC
* Navegantes - SC
* Nova Andradina - MS
* Orlândia - SP
* Orleans - SC
* Paranavaí - PR
* Pinhalzinho - SC
* Santa Rosa de Viterbo - SP
* Santo Amaro da Imperatriz - SC.
* São Joaquim - SC
* São José - SC
* São Mateus do Sul - PR
* São Miguel do Oeste - SC
* Sombrio - SC
* Tijucas - SC
* Torres - RS
* União da Vitória - PR
* Urussanga - SC
* Várzea Grande - MT
* Xanxerê - SC
* Xaxim - SC
