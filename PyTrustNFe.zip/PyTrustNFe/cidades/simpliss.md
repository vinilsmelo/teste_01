* Araras / SP
* Balneario Camboriu / SC
* Bambuí / MG
* Bandeirantes / PR
* Carapicuíba / SP
* Casa Branca / SP
* Cerquilho / SP
* Dois Corregos / SP
* Jales / SP
* Lagoa Da Prata / MG
* Osvaldo Cruz / SP
* Patrocinio / MG
* Piracicaba / SP
* Presidente Prudente / SP
* São João da Boa Vista / SP
* São José do Rio Pardo / SP
* Tupa / SP
* Vargem Grande do Sul / SP
