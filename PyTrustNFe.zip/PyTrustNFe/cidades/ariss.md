* Prefeitura de Rio das Pedras/SP
* Prefeitura de Piracaia/SP
* Prefeitura de Ipeúna/SP
* Prefeitura de Santa Maria da Serra/SP
